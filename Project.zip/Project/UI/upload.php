<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php session_start();
    if (!$_SESSION['current-user']) {
        header("location: ../UI/login.html");
        exit();
    } ?>

    <div><?php require ("header.php") ?></div> <br> <br> <br>

    <form action="../PHP/upload_success.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="MAX_FILE_SIZE" value="10000000">


        <table>

            <tr>
                <td>
                    Label:
                </td>
                <td>
                    <input type="text" name="label">
                </td>
            </tr>
            <tr>
                <td>
                    Upload a file:
                </td>

                <td>
                    <input type="file" name="userfile">
                </td>
            </tr>

            </tr>
        </table>
        <input type="submit" value="Upload File"> <br>
    </form>

    <button OnClick=" location.href='./upload.php' ">Cancel</button>
</body>

</html>