<html>

<head>
    <link rel="stylesheet" href="../Css/header.css">
</head>

<body>

    <!-- menu -->
    <table width="100%" class="header-table" cellpadding="4" cellspacing="4">
        <tr>
            <td width="25%">
                <a href="../Common/group_chat.php" class="button">Group Chat</a>
            <td width="25%">
                <a href="../Common/manage_users.php" class="button">Manage Users</a>
            <td width="25%">
                <a href="../Common/manage_documents.php" class="button">Manage Documents</a>
            <td width="25%">
                <a href="../UI/logout.php" class="button">Logout</a>
        </tr>
    </table>