<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../Css/common.css">
</head>

<body>
    <div>
        <h2><b>Register</b></h2>
        <br>
        <form action="../PHP/register_success.php" method="POST">
            <table>
                <tr>
                    <td>
                        Full Name:
                    </td>
                    <td>
                        <input type="text" name="fname">
                    </td>
                </tr>
                <tr>
                    <td>
                        Email:
                    </td>
                    <td>
                        <input type="text" name="email">
                    </td>
                </tr>
                <tr>
                    <td>
                        Password:
                    </td>

                    <td>
                        <input type="password" name="password">
                    </td>
                </tr>
                <tr>
                    <td>
                        Confirm Password:
                    </td>

                    <td>
                        <input type="password" name="confirmpassword">
                    </td>
                </tr>
            </table>



            <br>
            <input type="submit" value="Register">

        </form>
    </div>

</body>

</html>