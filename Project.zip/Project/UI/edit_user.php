<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../Css/common.css">
</head>

<body>
    <div>
        <?php session_start();
        if (!$_SESSION['current-user']) {
            header("location: ../UI/login.html");
            exit();
        } ?>

        <?php
        require ('header.php'); // whatever is there inside header.php will call it here
        ?>
        <h2><b>Edit User Information</b></h2>
        <br>
        <form action="../PHP/register_success.php" method="POST">
            <table>
                <tr>
                    <td>
                        Full Name:
                    </td>
                    <td>
                        <input type="text" name="fname">
                    </td>
                </tr>
                <tr>
                    <td>
                        Email:
                    </td>
                    <td>
                        <input type="text" name="email">
                    </td>
                </tr>

            </table>

            <br>
            <input type="submit" value="Save">

        </form>
    </div>

</body>

</html>