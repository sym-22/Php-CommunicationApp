<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../Css/common.css">
</head>

<body>
    <div>
        <h2><b>Welcome to Users module</b></h2>
        <br>
        <b>Existing users</b> <br> <br>
        <button OnClick=" location.href='./login.html' ">Login</button>
        <br>
        <br>
        <b>New Users </b><br> <br>
        <button OnClick=" location.href='./register.php' ">Register</button>
    </div>
</body>

</html>