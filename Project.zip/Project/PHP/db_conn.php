<?php

//Store all values in variables
$host = "localhost";
$username = "root";
$password = "";
$db_name = "comm_app";
$port = "3306";

//setting dsn
$dsn = "mysql:host=$host;dbname=$db_name";

try {

    // Set DB object, this will be used by application.
    $db = new PDO($dsn, $username, $password);

} catch (PDOException $e) {

    echo "Error connecting to DB: " . $e->getMessage();
}
