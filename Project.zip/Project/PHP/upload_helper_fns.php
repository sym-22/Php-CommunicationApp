<?php

// Add file info to DB
function addFileInfoToDB($label, $filename, $db, $current_user_id)
{

    // Insert query
    $query = "INSERT INTO documents (label, filename, user_id) VALUES (:label, :filename_placeholder, :userid)";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':label', $label);
    $stmt->bindParam(':filename_placeholder', $filename);
    $stmt->bindParam(':userid', $current_user_id);

    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<h3>Upload successful</h3>";
        header("Location: ../Common/manage_documents.php"); // redirect
    } else {
        echo "<p>An error has occurred.</p>";
    }

    $db = null;

}


// Uploads file to uploads folder
function uploadFile($uploaded_file_path)
{
    if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
        if (!move_uploaded_file($_FILES['userfile']['tmp_name'], $uploaded_file_path)) { // ?
            echo "Problem: Could not move file to destination directory";
            exit;
        }
    } else {
        echo "Problem: Possible file upload attack. Filename:";
        echo $_FILES['userfile']['name'];
        exit;
    }
}

