<?php

// To get Db object
require ("db_conn.php");


//check if any fields are null
if (!isset($_POST['fname']) || !isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['confirmpassword'])) {
    echo '<p>You have not entered all required details. Please go back and try again.</p>';
    exit;
}

// Get fields
$fname = $_POST["fname"];
$email = $_POST["email"];
$password = md5($_POST["password"]);
$confirmpassword = md5($_POST["confirmpassword"]);
$date = date('H:i, jS F Y');

// Check if passwords are same
if ($password != @$confirmpassword) {
    echo "<p>Passwords do not match</p>";
    exit;
}

$default_doc_id = 0;

// Insert into users
$query = "INSERT INTO users (full_name, email, password, document_id) VALUES (:fname, :email, :pass, :doc)";
$stmt = $db->prepare($query);

$stmt->bindParam(':fname', $fname);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':pass', $password);
$stmt->bindParam(':doc', $default_doc_id);

$stmt->execute();

if ($stmt->rowCount() > 0) {
    echo "<h3>Registration successful</h3>
    <br>
    <br>
    <p>Thank you for your registration</p>
    <br><br>
    <a href='../UI/welcome.php'>click to return to home page</a> ";
} else {
    echo "<p>An error has occurred.</p>";
}

$db = null;



