<?php
session_start();
require ("./db_conn.php");

//check if any fields are null
if (!isset($_POST['email']) || !isset($_POST['password'])) {
    echo '<p>You have not entered all required details. Please go back and try again.</p>
    <a href="../UI/login.html">click to return to Login</a>';
    exit;
}

//Get email and password
$email = $_POST["email"];
$password = md5($_POST["password"]);

//Check record in DB
$query = "SELECT user_id, full_name, email, password from users where email = :email and password = :password";
$stmt = $db->prepare($query);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':password', $password);

$stmt->execute();



if ($stmt->rowCount() > 0) {

    // Get name if record exists
    $result = $stmt->fetch(PDO::FETCH_OBJ);
    @$name = $result->full_name;
    @$user_id = $result->user_id;

    // Store in session
    $_SESSION['current-user'] = $name;
    $_SESSION['current-user-id'] = $user_id;

    require ("../UI/header.php");

    echo "<h3>Login successful</h3>
    <br>
    <br>
    <p>Welcome! </t> $name </p>";

} else {
    echo "<p>Invalid email/password. </p> <br>
    <a href='../UI/login.html'>click to return to login page</a>";
}