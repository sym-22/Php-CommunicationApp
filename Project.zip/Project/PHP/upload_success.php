<?php
session_start();
if (!$_SESSION['current-user']) {
    header("location: ../UI/login.html");
    exit();
}

require ("../PHP/db_conn.php");
require ("./upload_helper_fns.php");


if ($_FILES['userfile']['error'] > 0) {
    switch ($_FILES['userfile']['error']) {
        case 1:
            echo "File exceeded upload_max_file_size";
            break;

        case 2:
            echo "File exceeded upload max_file_size";
            break;

        case 3:
            echo "File only partially uploaded";
            break;

        case 4:
            echo "no file uploaded";
            break;
    }
}

//check if any fields are null
if (!isset($_POST['label'])) {
    echo '<p>You have not entered label. Please go back and try again.</p>';
    exit;
}

// Get form values
$label = $_POST['label'];
$filename = $_FILES['userfile']['name'];

// Set file path
$document_path = $_SERVER['DOCUMENT_ROOT'];
$uploaded_file_path = $document_path . "/Project/Uploads/" . $_FILES['userfile']['name'];

//current user

$current_user_id = $_SESSION['current-user-id'];

// Upload logic - function in "upload_helper_fns.php" file
uploadFile($uploaded_file_path);

// Insert in DB - function in "upload_helper_fns.php" file
addFileInfoToDB($label, $filename, $db, $current_user_id);
