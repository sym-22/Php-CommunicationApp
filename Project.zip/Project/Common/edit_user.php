<?php
session_start();
if (!$_SESSION['current-user']) {
  header("location: ../UI/login.html");
  exit();
}

echo "<h1>Edit user information</h1>";

//for Db object
require ("../PHP/db_conn.php");

//Get id from form
$id = $_REQUEST['id'];


//query DB
$query = "select * from users where user_id='$id'";
$stmt = $db->prepare($query);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_OBJ);

$current_fname = $result->full_name;
$current_email = $result->email;

if (isset($_POST['save'])) {

  $fname = $_POST['fname'];
  $email = $_POST['email'];


  if(trim($fname) == "" || trim($email) == "") {

    echo "<p>Please enter valid data, name or email cannot be blank</p>
    <a href='./edit_user.php?id=$id'>click to try again</a>";
    exit;
    
  }

  $query = "UPDATE users SET full_name='$fname', email='$email' WHERE user_id = '$id'";

  $stmt = $db->prepare($query);
  $stmt->execute();
  $result = $stmt->fetch(PDO::FETCH_OBJ);


  echo "saved";
  header("Location: ./manage_users.php"); // redirect

}

//close conenction
$db = null;
?>
<form method="post">
  <table border="0">
    <tr>
      <td>Full name</td>
      <td><input type="text" value="<?php echo $current_fname ?>" name="fname" /></td>
    </tr>

    <td>Email</td>
    <td><input type="text" value="<?php echo $current_email ?>" name="email" /></td>
    </tr>

    <td colspan="2"><input type="submit" name="save" value="Save" /></td>
    </tr>
  </table>
</form>