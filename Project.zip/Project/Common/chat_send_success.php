<?php
session_start();

// for DB connection
require ("../PHP/db_conn.php");

// Check if text exists
if (!isset($_POST['chat_txt'])) {
    header("location: ./group_chat.php");
    exit;
}

// Get chat text from form
$chat_text = $_POST["chat_txt"];
$upload_date = date("Y-m-d H:i:s");
$current_user_id = $_SESSION['current-user-id'];

// Insert to DB
$query = "INSERT INTO chats (chat_text, user_id, upload_date) VALUES (:chattxt, :userid, :uploaddate)";
$stmt = $db->prepare($query);

$stmt->bindParam(':chattxt', $chat_text);
$stmt->bindParam(':userid', $current_user_id);
$stmt->bindParam(':uploaddate', $upload_date);

$stmt->execute();

if ($stmt->rowCount() > 0) {
    header("location: ./group_chat.php");
} else {
    echo "<p>An error has occurred.</p>";
}