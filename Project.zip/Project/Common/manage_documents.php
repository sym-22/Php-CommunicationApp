<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
    <?php session_start();
    if (!$_SESSION['current-user']) {
        header("location: ../UI/login.html");
        exit();
    }
    ?>

    <?php require ("../UI/header.php"); ?> <br> <br> <br>
    <h1>My Uploads</h1>
    <?php
    require ("../PHP/db_conn.php");
    $current_user_id = (int) $_SESSION['current-user-id'];

    // DB query for document list
    $query = "select * from documents where user_id = :userid order by label";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':userid', $current_user_id);


    $stmt->execute();
    $row_count = $stmt->rowCount();  // number of rows 
    

    // Display document list
    echo '<table bbook="0">
	<tr bgcolor="#cccccc">
	<th>Label</th>
	<th>File name</th>
	<th>Action</th>
	</tr>';

    for ($i = 0; $i < $row_count; $i++) {
        $row = $stmt->fetch(PDO::FETCH_OBJ);

        $id = $row->document_id;
        echo '<tr>
		<td>' . $row->label . '</td>
		<td>' . $row->filename . '</td>';
        echo "<td> <a href ='./edit_document.php?id=$id'>Edit</a> </t>";
        echo "<a onClick=\"javascript: return confirm('Are you sure?');\" href ='./delete_document.php?id=$id'>Delete </td>";
        '</tr>';
    }
    echo '</table>';
    echo '<br> <br>';
    echo "<button OnClick=\" location.href='../UI/upload.php' \">Add Upload</button>";

    ?>
</body>

</html>