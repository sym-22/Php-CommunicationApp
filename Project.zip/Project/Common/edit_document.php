<?php
session_start();
if (!$_SESSION['current-user']) {
    header("location: ../UI/login.html");
    exit();
}

echo "<h1>Edit document</h1>";

//for Db object
require ("../PHP/db_conn.php");

//Get id from form
$id = $_REQUEST['id'];


//query DB
$query = "select * from documents where document_id='$id'";
$stmt = $db->prepare($query);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_OBJ);

$current_label = $result->label;

if (isset($_POST['save'])) {

    $label = $_POST['label'];

    // DB update query
    $query = "UPDATE documents SET label='$label' WHERE document_id = '$id'";

    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_OBJ);


    echo "saved";
    header("Location: ./manage_documents.php"); // redirect

}

//close conenction
$db = null;
?>
<form method="post">
    <table>
        <tr>
            <td>Label</td>
            <td><input type="text" value="<?php echo $current_label ?>" name="label" /></td>
        </tr>
        <tr>

            <td><input type="submit" name="save" value="Save" /></td>
        </tr>
        <tr>
            <td> <button OnClick=" location.href='./manage_documents.php' ">Cancel</button></td>
        </tr>
    </table>
</form>