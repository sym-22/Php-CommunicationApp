<!DOCTYPE html>
<html lang="en">

<head>
</head>

<?php
session_start();
if (!$_SESSION['current-user']) {
    header("location: ../UI/login.html");
    exit();
}
?>

<body>


    <?php
    require ("../UI/header.php"); ?> <br> <br> <br>
    <?php
    require ("../PHP/db_conn.php");

    // Get user name from session
    $current_user_name = $_SESSION['current-user'];

    // Query chats table
    $query = "select * from chats c join users u on u.user_id = c.user_id order by c.upload_date";

    $stmt = $db->prepare($query); // run query
    $stmt->execute();
    $row_count = $stmt->rowCount();  // number of rows 
    

    // Display chats
    
    echo '<table bbook="0">
	<tr bgcolor="#cccccc">
	<th>Group Chat</th>
	</tr>';

    for ($i = 0; $i < $row_count; $i++) {
        $row = $stmt->fetch(PDO::FETCH_OBJ);

        $chat_display_text = "[" . $row->upload_date . "] " . $row->full_name . ": " . $row->chat_text;

        $id = $row->user_id;
        echo '<tr>
		<td>' . $chat_display_text . '</td>';
        '</tr>';
    }
    echo '</table>';
    echo '<br> <br>';

    echo '<form action="../Common/chat_send_success.php" method="post">
    <input type="hidden" name="MAX_FILE_SIZE" value="10000000">' .

        $current_user_name . '&nbsp <input type="text" name="chat_txt"> </t>
     <input type="submit" value="Send"> 
     <button OnClick=" location.href=\'./group_chat.php\'">Refresh</button>
    </form>';


    ?>
</body>

</html>