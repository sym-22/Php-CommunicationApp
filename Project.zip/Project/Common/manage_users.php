<!DOCTYPE html>
<html lang="en">

<head>
</head>

<?php
session_start();
if (!$_SESSION['current-user']) {
    header("location: ../UI/login.html");
    exit();
}
?>

<body>


    <?php
    require ("../UI/header.php"); ?> <br> <br> <br>
    <h1>Users</h1>
    <?php
    require ("../PHP/db_conn.php");

    // Get users DB query
    $query = "select * from users order by full_name";

    $stmt = $db->prepare($query); // run query
    $stmt->execute();
    $row_count = $stmt->rowCount();  // number of rows 
    

    // Display users
    echo '<table bbook="0">
	<tr bgcolor="#cccccc">
	<th>Name</th>
	<th>User Email ID</th>
	<th>Action</th>
	</tr>';

    for ($i = 0; $i < $row_count; $i++) {
        $row = $stmt->fetch(PDO::FETCH_OBJ);

        $id = $row->user_id;
        echo '<tr>
		<td>' . $row->full_name . '</td>
		<td>' . $row->email . '</td>';
        echo "<td> <a href ='./edit_user.php?id=$id'>Edit</a> </t>";
        echo "<a onClick=\"javascript: return confirm('Are you sure?');\" href ='./delete_user.php?id=$id'>Delete</a> </td>";
        '</tr>';
    }
    echo '</table>';
    echo '<br>';

    ?>
</body>

</html>