<?php
session_start();
if (!$_SESSION['current-user']) {
    header("location: ../UI/login.html");
    exit();
}


//for Db object
require ("../PHP/db_conn.php");

//Get id from form
$id = $_REQUEST['id'];

//query DB
$query = "delete from documents where document_id='$id'";
$stmt = $db->prepare($query);
$stmt->execute();

header("Location: ./manage_documents.php"); // redirect

//close conenction
$db = null;
